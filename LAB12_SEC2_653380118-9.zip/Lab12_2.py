import MyPrint

MyPrint.MultiTable.get_table(12,5)
MyPrint.Square.print_square(4)
MyPrint.Square.print_triangle(4)
