while True:
    print('==== Select Menu ====')
    print('1. Add vehicle data')
    print('2. Show all vehicle')
    print('3. Show vehicle by type')
    print('4. Exit')
    x = int(input('Select menu number [1-4]:'))
    if x == 1:
        type_car = ''
        id = input('Enter vehicle id:')
        id = id+'\t'
        t_car = int(input("Enter vehicle's type [1:Sedan, 2:Van, 3:Truck]:"))
        if t_car == 1 :
            type_car = 'Sedan\n'
        if t_car == 2 :
            type_car = 'Van\n'
        if t_car == 3 :
            type_car = 'Truck\n'
        f = open('vehicles.txt', 'a+')
        f.write(id)
        f.write(type_car)
        f.close()
    if x == 2:
        f = open('vehicles.txt', 'r')
        
        if f.read() == '':
            print ('No Data!')
        else:
            count = int()
            print('')
            print('ID\tType')
            print('====================')
            f.seek(0,0)
            for i in f.read():
                if i == '\n':
                    count+=1
            f.seek(0,0)
            print(f.read()+'The number of vehicles is:',count)
        f.close()

    if x == 3:
        f = open('vehicles.txt', 'r')
        type_car = ''
        print('')
        t_car = int(input('Enter type id [1:Seden, 2:Van, 3:Truck]:'))
        if t_car == 1 :
            type_car = 'Sedan'
        if t_car == 2 :
            type_car = 'Van'
        if t_car == 3 :
            type_car = 'Truck'

        count = int()
        # st = f.read()
        # st1,st2 = st.split('\t')
        # st.reverse()

        # for i in st:
        #     if st == type_car:
        #         continue
        for i in f:
            
            st1, st2 = i.strip().split('\t')
            if st2 == type_car:
                print('ID:',st1)
                count+=1
            elif st2 != type_car:
                print('No Data!')
                break
                
                
        print('The number of',type_car,'is:',count)
        f.close()
    if x == 4:
        break