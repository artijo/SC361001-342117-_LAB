num = int(input('Please Enter Number: '))
if (num%2 == 0):
    print('===== Result =====\n',num,'is Even Number.\n==========')
else:
    print('===== Result =====\n',num,'is Odd Number.\n==========')